package ClassObjectFunction

class Hewan {
    var namaHewan: String = "Kucing"
    var jenis: String = "Mamalia"
    var jumlahKaki: String = "4"

    fun bersuara(): String{
        return("bersuara")
    }
    fun berjelan(): Int{
        return 4
    }
    fun makan(): String{
        return("bisa makan")
    }
}