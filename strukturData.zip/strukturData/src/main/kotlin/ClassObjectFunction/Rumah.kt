package ClassObjectFunction

class Rumah {
    //    atrribut
    var panjangRumah : Int = 100
    var lebarRumah : Int = 50
    var luasTanah : Int = 1500
    var namaPemilik : String = "Andika"
    var warnaRumah : String = "Biru"

    //    deklarasi function
    fun hidupkanLampu():String{
        return "Rumah bisa menghidupkan lampu"
    }

    fun naikTurunLift():String{
        return "Rumahnya ada lift"
    }

    fun tahanPanas(): String{
        return "Rumahnya tahan panas"
    }
}