package ClassObjectFunction

fun main(){
    val kucing = Hewan()

    val gajah = Hewan()
    val macan = Hewan()

}