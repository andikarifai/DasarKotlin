package OOP

fun main(){
    val buah = Buah()
    buah.deskripsi("apel","a")

}

class Buah(){
    fun deskripsi (name : String){

    }
    fun deskripsi ( warna : String, vit : String){

    }
}